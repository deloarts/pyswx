"""
PYSWX CONSTANTS
"""

VERSION = "0.0.1"
