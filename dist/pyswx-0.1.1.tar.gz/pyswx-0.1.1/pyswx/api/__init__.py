"""
SolidWorks 2024 API Python Wrapper

Reference:
https://help.solidworks.com/2024/english/api/sldworksapiprogguide/Welcome.html
"""
