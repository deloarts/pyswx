"""
SolidWorks.Interop.swconst Namespace

Reference:
https://help.solidworks.com/2024/english/api/SWHelp_List.html?id=77cb05a40104402eaab7716b178965a3#Pg0
"""
