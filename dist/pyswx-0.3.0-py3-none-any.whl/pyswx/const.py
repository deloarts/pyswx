"""
PYSWX CONSTANTS
"""

VERSION = "0.3.0"
