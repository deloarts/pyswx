"""
SolidWorks.Interop.swpublished Namespace

Reference:
https://help.solidworks.com/2024/english/api/SWHelp_List.html?id=da0715d29cec4d5b9b38f14d51e90c1f#Pg0
"""
