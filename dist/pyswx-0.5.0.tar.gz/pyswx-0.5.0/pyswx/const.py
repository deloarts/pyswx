"""
PYSWX CONSTANTS
"""

VERSION = "0.5.0"
