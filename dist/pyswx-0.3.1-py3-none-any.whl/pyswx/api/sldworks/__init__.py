"""
SolidWorks.Interop.sldworks Namespace Interfaces

Reference:
https://help.solidworks.com/2024/english/api/SWHelp_List.html?id=7a61cd45144141a3ba4dcb8d426ebce9#Pg0
"""
