"""
PYSWX CONSTANTS
"""

VERSION = "0.2.0"
