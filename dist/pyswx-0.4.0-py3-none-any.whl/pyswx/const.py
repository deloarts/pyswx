"""
PYSWX CONSTANTS
"""

VERSION = "0.4.0"
