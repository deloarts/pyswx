"""
SWPUBLISHED INTERFACES

Reference:
https://help.solidworks.com/2024/english/api/SWHelp_List.html?id=2f8543db25174df1b555eacac222710c#Pg0
"""
