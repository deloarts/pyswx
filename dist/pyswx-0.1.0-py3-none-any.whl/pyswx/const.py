"""
PYSWX CONSTANTS
"""

VERSION = "0.1.0"
